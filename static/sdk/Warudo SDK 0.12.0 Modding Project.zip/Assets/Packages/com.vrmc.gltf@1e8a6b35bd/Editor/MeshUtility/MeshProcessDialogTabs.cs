namespace UniGLTF.MeshUtility
{
    public enum MeshProcessDialogTabs
    {
        MeshSeparator,
        MeshIntegrator,
        BoneMeshEraser,
    }
}
