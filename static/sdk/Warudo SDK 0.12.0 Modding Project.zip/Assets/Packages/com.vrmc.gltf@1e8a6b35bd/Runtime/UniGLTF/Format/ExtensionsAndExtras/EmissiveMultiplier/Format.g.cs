﻿// This file is generated from JsonSchema. Don't modify this source code.
using System;
using System.Collections.Generic;


namespace UniGLTF.Extensions.VRMC_materials_hdr_emissiveMultiplier
{

    public class VRMC_materials_hdr_emissiveMultiplier
    {
        public const string ExtensionName = "VRMC_materials_hdr_emissiveMultiplier";

        // Dictionary object with extension-specific objects.
        public object Extensions;

        // Application-specific data.
        public object Extras;

        // A multiplier for emissiveFactor
        public float? EmissiveMultiplier;
    }
}
