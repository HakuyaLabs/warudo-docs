
namespace UniGLTF
{
    public static partial class UniGLTFVersion
    {
        public const int MAJOR = 2;
        public const int MINOR = 43;
        public const int PATCH = 0;
        public const string VERSION = "2.43.0";
    }
}
