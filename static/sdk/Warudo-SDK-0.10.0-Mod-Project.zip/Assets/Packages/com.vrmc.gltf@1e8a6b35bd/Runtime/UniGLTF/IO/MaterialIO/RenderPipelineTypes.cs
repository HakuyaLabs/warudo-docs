namespace UniGLTF
{
    /// <summary>
    /// TODO: HDRP ?
    /// TODO: UserCustom ?
    /// </summary>
    public enum RenderPipelineTypes
    {
        BuiltinRenderPipeline,
        UniversalRenderPipeline,
    }
}
