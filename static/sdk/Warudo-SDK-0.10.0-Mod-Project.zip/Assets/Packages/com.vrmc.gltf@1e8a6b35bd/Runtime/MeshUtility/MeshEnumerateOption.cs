namespace UniGLTF.MeshUtility
{
    public enum MeshEnumerateOption
    {
        OnlyWithBlendShape,
        OnlyWithoutBlendShape,
        All,
    }
}
