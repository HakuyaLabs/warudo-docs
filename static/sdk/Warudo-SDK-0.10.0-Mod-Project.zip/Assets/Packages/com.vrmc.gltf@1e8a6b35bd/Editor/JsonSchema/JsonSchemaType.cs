namespace UniGLTF.JsonSchema
{
    public enum JsonSchemaType
    {
        Unknown,
        Object,
        Array,
        String,
        Number,
        Integer,
        Boolean,
        Enum,
        EnumString,
    }
}
