using System.Collections.Generic;

namespace UniGLTF.JsonSchema.Schemas
{
    public static class JsonSchemaBaseExtensions
    {


    }
}
